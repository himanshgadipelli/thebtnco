CREATE TRIGGER trigger_name
BEFORE INSERT ON customer
FOR EACH ROW
  BEGIN
   DECLARE serialno INT;
   SET serialno = (SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='Customer');
   SET new.CustomerID = CONCAT(substring(new.FirstName, 1, 2),substring(new.LastName, 1, 2),LPAD(serialno,5,'0'));
END;
