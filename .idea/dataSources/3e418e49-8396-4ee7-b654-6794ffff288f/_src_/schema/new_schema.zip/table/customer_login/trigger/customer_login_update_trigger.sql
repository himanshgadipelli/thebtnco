CREATE TRIGGER customer_login_update_trigger
BEFORE UPDATE ON customer_login
FOR EACH ROW
  BEGIN
    INSERT INTO Customer_Login_History
    (
      CustomerID,
      UserID,
      UserPassword,
      CreatedDate
    )
    VALUES
    (
      Customer_Login.CustomerID,
      Customer_Login.UserID,
      Customer_Login.UserPassword
    );
  END;
